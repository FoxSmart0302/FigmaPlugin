import WebMercatorViewport from './web-mercator-viewport';

export default function getBounds(viewport : WebMercatorViewport, z? : number) : Array<number[]>;
