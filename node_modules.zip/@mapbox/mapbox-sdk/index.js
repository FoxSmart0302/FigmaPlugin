'use strict';

var client = require('./lib/client');

module.exports = client;
