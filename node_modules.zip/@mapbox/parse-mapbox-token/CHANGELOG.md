# Changelog

## 0.2.0

- Use `base-64` behind the scenes to enable React Native compatibility.

## 0.1.0

- Start this log.
