# Installation
> `npm install --save @types/normalize-package-data`

# Summary
This package contains type definitions for normalize-package-data (https://github.com/npm/normalize-package-data#readme).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/normalize-package-data

Additional Details
 * Last updated: Sun, 07 Jan 2018 07:34:38 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Jeff Dickey <https://github.com/jdxcode>.
