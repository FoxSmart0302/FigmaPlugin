declare var global: NodeJS.Global;
