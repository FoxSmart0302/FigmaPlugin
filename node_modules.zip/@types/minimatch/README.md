# Installation
> `npm install --save @types/minimatch`

# Summary
This package contains type definitions for Minimatch (https://github.com/isaacs/minimatch).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/minimatch

Additional Details
 * Last updated: Thu, 04 Jan 2018 23:26:01 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by vvakame <https://github.com/vvakame>, Shant Marouti <https://github.com/shantmarouti>.
